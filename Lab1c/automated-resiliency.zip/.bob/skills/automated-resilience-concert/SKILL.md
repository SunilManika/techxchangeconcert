---
name: automate-resilience
description: Build resilient, secure, and observable systems with API integration patterns, comprehensive monitoring, security automation, and IBM Carbon Design System UI for Concert API and production applications
---

Use this skill when working on:

**API Integration & Resilience:**
- Building resilient Concert API integrations with retry logic
- Implementing circuit breakers and bulkhead patterns
- Creating API health monitoring and alerting systems
- Optimizing API request patterns and batching
- Implementing rate limiting and throttling mechanisms
- Building API response caching strategies
- Creating fallback mechanisms for API failures

**Monitoring & Observability:**
- Implementing comprehensive logging systems
- Building metrics collection and visualization
- Creating real-time alerting and notification systems
- Developing health check endpoints and monitoring
- Implementing distributed tracing for request flows
- Building performance monitoring dashboards
- Creating SLA/SLO tracking and reporting

**Security & Automation:**
- Automating security scanning and vulnerability tracking workflows
- Building risk scoring and prioritization systems
- Creating automated security assessment pipelines
- Implementing vulnerability remediation automation
- Developing security compliance checking and reporting
- Building automated threat detection systems
- Implementing secure credential management systems

**IBM Carbon Design System UI:**
- Building dashboards with `@carbon/react`, `@carbon/icons-react`, `@carbon/charts-react`
- Implementing Carbon UI Shell (g100 dark header, subheader band, footer)
- Creating KPI tiles, DataTables, Charts, Tags, Notifications using Carbon exclusively
- Enforcing Carbon typography (IBM Plex Sans), colour tokens, spacing, and accessibility rules
- Avoiding forbidden patterns (raw `<input>`, non-existent icon names, wrong Tag types)

---

## Workflow

<Steps>
<Step>
**Understand the Requirement**
- Identify the primary objective (API integration, monitoring, security, etc.)
- Determine the scope (single component, system-wide, infrastructure)
- Assess criticality and priority level
- Identify dependencies and integration points
</Step>

<Step>
**Gather Context**
- Use `list_files` to understand project structure
- Use `read_file` to examine existing implementations
- Use `search_files` to find related code patterns
- Use `list_code_definition_names` to identify key components
- Review existing error handling, monitoring, and security patterns
</Step>

<Step>
**Design Resilient Solution**
- Identify failure points and edge cases
- Design error handling strategy with retry logic and exponential backoff
- Plan monitoring and observability (metrics, logs, alerts)
- Design caching strategy with appropriate TTLs
- Plan security measures (credential management, audit logging)
</Step>

<Step>
**Implement Core Features**

**For API Integration:**
- Setup API client with connection pooling
- Configure authentication headers (Accept, Authorization, InstanceID, Content-Type)
- Implement retry logic with exponential backoff (1s, 2s, 4s, 8s, 16s)
- Add rate limiting with token bucket algorithm
- Implement comprehensive error handling by status code
- Add type-safe data handling for API responses
- Implement caching with appropriate TTLs

**For Monitoring:**
- Setup structured logging with context and correlation IDs
- Implement metrics collection (counters, gauges, histograms)
- Create health check endpoints (liveness and readiness)
- Build monitoring dashboards for key metrics
- Configure alerting with severity levels
- Add distributed tracing support

**For Security:**
- Implement secure credential management (environment variables, vaults)
- Build vulnerability scanning automation
- Implement risk scoring with CVSS and context
- Create compliance automation workflows
- Add certificate expiration monitoring
- Implement security audit logging

**For IBM Carbon Design System UI:**
- Wrap the app in `<Theme theme="g100">` so the header is dark, content area is light
- Use the Page Header pattern (circle icon + light-weight `h1` + subtitle + Refresh button)
- Build KPI tiles with `<Tile>` and semantic `borderTop` accent colours
- Use `<DataTable>` with `<TableToolbarSearch>` — never a raw `<input>` in a toolbar
- Wrap all charts in `<Tile>` with a section label; always set `toolbar: { enabled: false }`
- Use `<Tag size="sm">` in tables; verify icon names exist in `@carbon/icons-react` v11
- Use `renderIcon` on `<Button>` — never wrap icon + text manually
- Show `<SkeletonText>` during loading, `<InlineNotification lowContrast>` for errors/cache
- See `ui-patterns/carbon-design.md` for complete reference with all verified patterns
</Step>

<Step>
**Test and Validate**
- Test error scenarios (network failures, timeouts, rate limiting)
- Verify monitoring (logs, metrics, alerts, health checks)
- Perform security testing (credential validation, vulnerability scanning)
- Conduct performance testing (load, stress, cache effectiveness)
- Validate resilience patterns (retry, circuit breaker, fallback)
</Step>

<Step>
**Document Implementation**
- Add code comments and docstrings
- Update README with new features
- Create runbooks for common issues
- Document architecture and data flows
- Create alert response playbooks
</Step>
</Steps>

---

## API Resilience Patterns

### Resilient API Client Setup
```python
import requests
from typing import Optional, Dict, Any

class ResilientAPIClient:
    """API client with comprehensive resilience features."""
    
    def __init__(self, base_url: str, api_key: str, instance_id: str):
        self.base_url = base_url
        self.session = requests.Session()
        
        # Configure required headers for Concert API
        self.session.headers.update({
            "Accept": "application/json",
            "Authorization": f"C_API_KEY {api_key}",
            "InstanceID": instance_id,
            "Content-Type": "application/json"
        })
    
    def make_request(self, endpoint: str, max_retries: int = 3, **kwargs):
        """Make resilient API request with retry logic."""
        url = f"{self.base_url}{endpoint}"
        
        for attempt in range(max_retries):
            try:
                response = self.session.get(url, timeout=(5, 30), **kwargs)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                if attempt == max_retries - 1:
                    logger.error(f"Failed after {max_retries} attempts: {e}")
                    return None
                wait_time = 2 ** attempt
                time.sleep(wait_time)
        return None
```

### Type-Safe Data Handling
```python
def safe_string_operation(value: Any) -> str:
    """Safely convert to string before operations."""
    return str(value).lower() if value else ""

def safe_date_parsing(date_value: Any) -> Optional[datetime]:
    """
    Parse date handling multiple formats.
    Uses > 9_999_999_999 heuristic to detect ms vs s timestamps.
    [VERIFIED OCP: validity_end_date is SECONDS, not milliseconds]
    """
    if isinstance(date_value, int):
        if date_value > 9_999_999_999:
            return datetime.fromtimestamp(date_value / 1000)  # milliseconds
        return datetime.fromtimestamp(date_value)              # seconds
    elif isinstance(date_value, str):
        try:
            return datetime.fromisoformat(date_value.replace('Z', '+00:00'))
        except ValueError:
            return None
    return None
```

### Integer-Zero Criticality (CRITICAL — OCP deployments)
```python
def safe_criticality(value: Any) -> str:
    """
    Concert OCP deployments return criticality as integer 0 when unset.
    Normalise to empty string so the UI shows dash instead of 0.
    """
    if not value or value == 0 or str(value) == "0":
        return ""
    return str(value).lower()

# Usage
criticality = safe_criticality(app.get("criticality", ""))
data_impact  = safe_criticality(app.get("data_impact_risk", ""))
```

---

## Monitoring Patterns

### Structured Logging
```python
import logging
import json
from datetime import datetime, timezone

class StructuredLogger:
    """Logger with structured output and context."""
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        self.context = {}
    
    def set_context(self, **kwargs):
        """Set context for all subsequent logs."""
        self.context.update(kwargs)
    
    def info(self, message: str, **kwargs):
        """Log info with context."""
        log_data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),  # timezone-aware [VERIFIED OCP fix]
            "level": "INFO",
            "message": message,
            "context": self.context,
            **kwargs
        }
        self.logger.info(json.dumps(log_data))
```

### Health Check Endpoints (FastAPI)
```python
from fastapi import FastAPI
from datetime import datetime, timezone

app = FastAPI()

@app.get('/health')
async def health_check():
    """Basic health check endpoint."""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

@app.get('/health/ready')
async def readiness_check():
    """Readiness check with dependencies."""
    checks = {
        "api": await check_api_connection(),
        "cache": check_cache()
    }
    all_healthy = all(checks.values())
    status_code = 200 if all_healthy else 503
    return JSONResponse(
        content={
            "status": "ready" if all_healthy else "not_ready",
            "checks": checks
        },
        status_code=status_code,
    )
```

---

## Security Patterns

### Secure Credential Management
```python
import os
from pathlib import Path
from dotenv import load_dotenv

def _load_env_file():
    """
    Search CWD then project root for .env so credentials are found
    whether the process starts from backend/ or the project root.
    [VERIFIED OCP fix]
    """
    cwd_env = Path(".env")
    parent_env = Path(__file__).resolve().parent.parent.parent / ".env"
    if cwd_env.exists():
        load_dotenv(cwd_env)
    elif parent_env.exists():
        load_dotenv(parent_env)

class SecureConfig:
    """Secure configuration management."""
    
    def __init__(self):
        _load_env_file()
        self.api_key = self._get_required("CONCERT_API_KEY")
        self.instance_id = self._get_required("CONCERT_INSTANCE_ID")
        self.base_url = self._get_required("CONCERT_BASE_URL")
    
    def _get_required(self, key: str) -> str:
        """Get required environment variable."""
        value = os.getenv(key)
        if not value:
            raise ValueError(f"Required environment variable {key} not set")
        return value
    
    def validate(self):
        """Validate configuration."""
        if not self.base_url.startswith("https://"):
            raise ValueError("Base URL must use HTTPS")
        logger.info("Configuration validated successfully")
```

### Vulnerability Risk Scoring
```python
def calculate_risk_score(vulnerability: Dict) -> float:
    """Calculate comprehensive risk score."""
    cvss = vulnerability.get("cvss", 0)
    
    exploitability = {
        "high": 2.0,
        "medium": 1.5,
        "low": 1.0
    }.get(vulnerability.get("exploitability", "low"), 1.0)
    
    criticality = {
        "critical": 2.0,
        "high": 1.5,
        "medium": 1.0,
        "low": 0.5
    }.get(vulnerability.get("asset_criticality", "medium"), 1.0)
    
    risk_score = cvss * exploitability * criticality / 2
    return min(risk_score, 10.0)
```

---

## Critical Requirements

### Concert API Headers (MUST INCLUDE)
All Concert API requests MUST include these headers:
- `Accept: application/json`
- `Authorization: C_API_KEY {api_key}` (proper capitalization!)
- `InstanceID: {instance_id}` (UUID format)
- `Content-Type: application/json`

**OCP / TechZone Deployments:** Use `InstanceID: 0000-0000-0000-0000` when a specific instance UUID is not available. `C_API_KEY` works for both SaaS and OCP Concert deployments.

### Type Safety
Always validate data types before operations:
- Use `str(value).lower()` instead of `value.lower()`
- Check `isinstance(date, int)` before parsing timestamps
- Use `.get()` with defaults instead of direct dictionary access
- Wrap parsing operations in try-except blocks

### Error Handling Strategy
- 400-499: Client errors - log and alert, don't retry
- 500-599: Server errors - retry with exponential backoff
- 429: Rate limited - wait and retry
- Network errors: Retry up to 3 times with backoff

**CRITICAL — Single-App Endpoint Fallback:**
Some Concert deployments (OCP in particular) return HTTP 400 for `GET /applications/{id}`.
Always fall back to scanning the list endpoint:
```python
async def get_application(client, app_id: str):
    # Primary: single-app endpoint
    data, from_cache = await client.get(f"/core/api/v1/applications/{app_id}")
    if data and "id" in data:
        return normalize_application(data)

    # Fallback: scan the list (OCP returns 400 on the single-app endpoint)
    list_data, _ = await client.get("/core/api/v1/applications",
                                    params={"page_size": 500})
    if list_data:
        for app in list_data.get("applications", []):
            if app.get("id") == app_id:
                return normalize_application(app)
    return None
```

**CRITICAL — Optional Response Fields in Pydantic Models:**
Type wrapper fields as `Optional` to prevent `ValidationError → HTTP 500` when a Concert endpoint returns an error:
```python
# WRONG — crashes with ValidationError when Concert returns 400/empty
class ApplicationDetailResponse(BaseModel):
    application: Application

# CORRECT
from typing import Optional
class ApplicationDetailResponse(BaseModel):
    application: Optional[Application] = None  # safe null fallback
    from_cache: bool = False
```

### Caching Strategy
Set TTL based on data volatility:
- Real-time data: 1-5 minutes
- Semi-static data: 15-30 minutes
- Static data: 1-4 hours

### .env Discovery — Multi-Directory Search (CRITICAL)
When `uvicorn` starts from `backend/`, `env_file=".env"` only checks CWD.
Search both CWD and project root so credentials are found regardless of start directory:
```python
from pathlib import Path

def _find_env_file() -> list[str]:
    """Search ./env then project root — first found wins."""
    cwd_env    = Path(".env")
    parent_env = Path(__file__).parent.parent.parent.parent / ".env"
    paths = []
    if cwd_env.exists():
        paths.append(str(cwd_env))
    if parent_env.exists() and parent_env.resolve() != cwd_env.resolve():
        paths.append(str(parent_env))
    return paths if paths else [".env"]

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=_find_env_file(), ...)
```


## IBM Carbon Design System UI Patterns

The dashboard frontend is built exclusively with IBM Carbon Design System. Follow these patterns strictly.

### Dependencies
```json
{
  "@carbon/react": "^1.68.0",
  "@carbon/styles": "^1.68.0",
  "@carbon/icons-react": "^11.40.0",
  "@carbon/charts-react": "^1.23.0",
  "@carbon/charts": "^1.23.0"
}
```

### App Shell (g100 dark header)
```tsx
import { Header, HeaderName, HeaderNavigation, HeaderMenuItem,
         HeaderGlobalBar, HeaderGlobalAction, SkipToContent, Theme } from '@carbon/react';
import { IbmWatsonDiscovery } from '@carbon/icons-react';

// Theme g100 = dark header; wrap entire app in <Theme theme="g100">
// Content area uses background: #f4f4f4 (Carbon Gray 10)
// Individual tiles/cards use background: #ffffff
```

### Page Header Pattern (consistent across all 5 tabs)
```tsx
// Coloured circle icon + h1 (fontWeight 300, IBM Plex Sans) + subtitle
<div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
  <div style={{ background: '#0f62fe', borderRadius: '50%', width: '2.5rem', height: '2.5rem',
                display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <Security size={20} style={{ color: '#fff' }} />
  </div>
  <div>
    <h1 style={{ fontSize: '1.5rem', fontWeight: 300, color: '#161616', margin: 0,
                 fontFamily: '"IBM Plex Sans", sans-serif' }}>
      Application Security
    </h1>
    <p style={{ fontSize: '0.875rem', color: '#6f6f6f', margin: 0 }}>Subtitle text</p>
  </div>
</div>
```

### KPI Tile Pattern (accent border-top per semantic status)
```tsx
// Accent colours: blue=#0f62fe  red=#da1e28  orange=#ff832b
//                 green=#24a148 purple=#8a3ffc teal=#009d9a
<Tile style={{ borderTop: '3px solid #da1e28', background: '#fff', padding: '1rem' }}>
  <p style={{ fontSize: '0.6875rem', fontWeight: 600, letterSpacing: '0.08em',
              textTransform: 'uppercase', color: '#6f6f6f' }}>Critical</p>
  <p style={{ fontSize: '2rem', fontWeight: 300, color: '#161616',
              fontFamily: '"IBM Plex Sans", sans-serif' }}>{value}</p>
</Tile>
```

### Severity / Status Tag sizes
Always use `size="sm"` on `<Tag>` in tables and compact layouts.
```tsx
// Severity
const SEV_TYPE = { critical: 'red', high: 'magenta', medium: 'teal', low: 'cyan', none: 'cool-gray' };
<Tag type={SEV_TYPE[severity]} size="sm">{severity}</Tag>

// Certificate status
const CERT_TYPE = { expired: 'red', expiring_soon: 'teal', valid: 'green' };
```

### Carbon DataTable with search
```tsx
import { DataTable, Table, TableHead, TableRow, TableHeader, TableBody, TableCell,
         TableContainer, TableToolbar, TableToolbarContent, TableToolbarSearch,
         Pagination } from '@carbon/react';

// Always use TableToolbarSearch (not raw <input>) in TableToolbar
<TableToolbarSearch
  placeholder="Search…"
  onChange={(_e, value?) => setSearch(value ?? '')}
  persistent
/>
// Always use useZebraStyles on <Table> for readability
<Table size="md" useZebraStyles>
```

### Active-row highlight pattern
```tsx
// Selected row — blue tint + left border, not custom background colours
<TableRow style={{
  background: isSelected ? '#edf5ff' : undefined,
  borderLeft: isSelected ? '3px solid #0f62fe' : '3px solid transparent',
}}>
```

### Carbon Charts — always inside a Tile
```tsx
import { SimpleBarChart, DonutChart, LineChart } from '@carbon/charts-react';
import '@carbon/charts-react/styles.css';

// Section label above every chart
<p style={{ fontSize: '0.6875rem', fontWeight: 600, letterSpacing: '0.08em',
            textTransform: 'uppercase', color: '#6f6f6f', marginBottom: '0.75rem' }}>
  Finding Distribution by Severity
</p>
<SimpleBarChart data={data} options={{ toolbar: { enabled: false }, height: '220px', ... }} />
```

### Button renderIcon pattern
Always use `renderIcon` for icon buttons instead of wrapping content:
```tsx
import { Renew, ArrowRight } from '@carbon/icons-react';

<Button kind="tertiary" size="sm" renderIcon={Renew} iconDescription="Refresh" onClick={refresh}>
  Refresh
</Button>

// Icon-only button
<Button kind="ghost" size="sm" hasIconOnly renderIcon={Close} iconDescription="Close" onClick={...} />
```

### InlineNotification (full-width, lowContrast)
```tsx
<InlineNotification
  kind="error"          // error | warning | info | success
  title="Alert title"
  subtitle="Detail text"
  lowContrast           // always lowContrast in content areas
  hideCloseButton
  style={{ maxWidth: '100%' }}
/>
```

### Colour-coded text cells (no Tag)
For numeric cells that need semantic colour (e.g. days remaining):
```tsx
function DaysRemainingCell({ days }: { days: number }) {
  const color = days < 0 ? '#da1e28' : days <= 30 ? '#ff832b' : '#24a148';
  return <span style={{ color, fontWeight: 600, fontSize: '0.875rem' }}>
    {formatDaysRemaining(days)}
  </span>;
}
```

### Forbidden patterns
- ❌ `className="cds--heading-04"` on `<h1>` — use inline styles with IBM Plex Sans
- ❌ `<div style={{ background: '#fff', padding: '1rem' }}>` wrapping charts — wrap in `<Tile>` instead
- ❌ Raw `<input>` inside `TableToolbar` — use `<TableToolbarSearch>`
- ❌ `<Button kind="tertiary">← Back</Button>` — use `renderIcon={ArrowLeft}` with text
- ❌ `Tag type="orange"` — Carbon has no orange Tag; use `type="teal"` or colour-coded text


---

## Supporting Files

Refer to these files for detailed implementations:

| File | Contents |
|---|---|
| `api-resilience/api-patterns.md` | Rate limiter, circuit breaker, caching, resilient client, OCP deployment patterns |
| `api-resilience/concert-api-reference.md` | All Concert API endpoints — verified OCP ground truth |
| `monitoring-observability/monitoring-patterns.md` | Structured logging, FastAPI tracing middleware, metrics, health checks |
| `security-automation/security-checklist.md` | Credential management, vulnerability scanning, deployment checklist |
| `ui-patterns/carbon-design.md` | **IBM Carbon Design System** — complete UI reference: App Shell, KPI tiles, DataTable, Charts, Tags, Buttons, Notifications, Grid, colour tokens, forbidden patterns |

---

## Best Practices

**Backend / API:**
1. **Always read files before modifying** — Use `read_file` to get exact content before any edit
2. **Use type-safe operations** — Validate types before string/date operations; use `safe_criticality()`, `safe_date_parsing()`
3. **Implement comprehensive logging** — Log at key decision points with `structlog`; never log secrets
4. **Add retry logic** — Exponential backoff for transient failures; skip retry on 400–499
5. **Monitor everything** — Metrics, logs, alerts, health checks; use `datetime.now(timezone.utc)` (never naive)
6. **Secure credentials** — Never hardcode; use `.env` with `_find_env_file()` for multi-directory discovery
7. **Test error scenarios** — Network failures, timeouts, rate limiting, circuit breaker open state
8. **Document thoroughly** — Code comments, runbooks, architecture docs

**IBM Carbon Design System UI:**
9. **Wrap in `<Theme theme="g100">`** — Dark header, light content area; never mix themes
10. **Check icon names before use** — Verify in `@carbon/icons-react` v11 exports; `Health`, `Software`, `PackageImport` do not exist
11. **Always `size="sm"` on Tags in tables** — Full-size Tags are for page-level status badges only
12. **Charts inside `<Tile>` always** — Never a bare `<div>`; always `toolbar: { enabled: false }`
13. **`<TableToolbarSearch>` not `<input>`** — Raw inputs inside `TableToolbar` break Carbon keyboard navigation
14. **`renderIcon` on `<Button>`** — Never manually wrap icon + text; always use the `renderIcon` prop
15. **`SkeletonText` has no `style` prop** — Use `width` and `heading` props only
16. **No `Tag type="orange"`** — Carbon has no orange Tag; use colour-coded `<span>` for numeric cells

## Verified Against Live Concert (OCP / TechZone)

The following were discovered by running against a real Concert OCP deployment and must be treated as ground truth over any earlier documentation:

| Finding | Impact | Fix |
|---|---|---|
| `GET /applications/{id}` returns 400 on OCP | Pydantic `ValidationError` → HTTP 500 | Fall back to list scan; type response as `Optional` |
| `criticality` field is integer `0` (not string) when unset | UI shows `"0"` instead of blank/dash | `safe_criticality()` — treat `0` as empty string |
| `validity_end_date` is **seconds** on OCP (not milliseconds) | Certificate expiry shows wrong date/status | Use `> 9_999_999_999` heuristic to detect ms vs s |
| Certificate `status` field exists directly on the object | Redundant recomputation from days | Prefer `cert.get("status")` over computed value |
| `recommendation_id` (not `id`) in recommendations | ID missing from normalised records | Check `raw.get("recommendation_id") or raw.get("id")` |
| `recommendation` field (not `justification`) | Action detail missing | Check `raw.get("recommendation") or raw.get("justification")` |
| `InstanceID: 0000-0000-0000-0000` required on OCP | 401 Unauthorized without it | Always include InstanceID header even on OCP |
| `.env` not found when starting from `backend/` subdir | All credentials missing → empty data | Search both CWD and project root for `.env` |
| CVE endpoint does not return `package_name`, `package_version`, `fix_version`, `status` | Columns empty in UI | Remove those 4 columns; show `priority`, `findings`, `component_type`, `state` instead |
| `findings: null`, `associations.build_artifacts: null` on every CVE | No package detail available | No `?expand=findings` param exists; no per-CVE sub-endpoint available (404/403) |
| `highest_finding_priority` is a string `"Deprioritized"` on OCP, not int | `int()` cast crashes normalizer | Use `str(priority)` directly, no integer conversion |