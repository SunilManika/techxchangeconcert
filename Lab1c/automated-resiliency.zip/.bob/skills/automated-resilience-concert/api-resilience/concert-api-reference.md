# Concert API Reference

Complete reference for IBM Concert API endpoints with resilience patterns.
Entries marked **[VERIFIED OCP]** were confirmed against a live Concert OCP / TechZone deployment.

---

## Authentication Headers (CRITICAL)

All Concert API requests MUST include these headers:

```python
headers = {
    "Accept": "application/json",              # Required
    "Authorization": f"C_API_KEY {api_key}",   # Required - proper capitalization
    "InstanceID": instance_id,                 # Required - UUID format
    "Content-Type": "application/json"
}
```

**Common Errors:**
- Missing Accept header → content negotiation issues
- Lowercase "authorization" → may fail with proxies
- Missing InstanceID → `instance ID Not Found` (HTTP 401)
- Wrong auth type → Use `C_API_KEY` for both SaaS **and** OCP deployments

**OCP / TechZone InstanceID [VERIFIED OCP]:**
When a specific instance UUID is not known, use `InstanceID: 0000-0000-0000-0000`.
Both `ZenAPIKey` and `C_API_KEY` headers are attempted — only `C_API_KEY` with
`InstanceID: 0000-0000-0000-0000` returns HTTP 200 on OCP Concert.

```python
# OCP deployment — confirmed working combination
headers = {
    "Authorization": "C_API_KEY <your_key>",
    "InstanceID": "0000-0000-0000-0000",
    "Accept": "application/json",
    "Content-Type": "application/json",
}
```

---

## Base Configuration

```python
BASE_URL = "https://your-instance.concert.example.com"  # NO trailing slash
TIMEOUT = (5, 30)  # connect, read
MAX_RETRIES = 3
```

---

## Application Endpoints

### GET /core/api/v1/applications
List all applications with pagination.

**Response Structure:**
```json
{
  "pagination": {
    "total_count": 3,
    "total_pages": 1,
    "page_size": 100,
    "page_number": 1
  },
  "applications": [
    {
      "id": "uuid",
      "name": "Retail App",
      "version": "",
      "latest": true,
      "criticality": 0,
      "data_impact_risk": 0,
      "business_units": [],
      "tags": [],
      "last_updated_on": 1787664523,
      "last_updated_by": "user@example.com",
      "associations": {
        "environments": [...],
        "build_artifacts": [...],
        "source_repos": [...],
        "resources": [...],
        "releases": [...]
      }
    }
  ]
}
```

**Key Fields:**
- `id`, `name`, `version`, `latest`
- `criticality`, `data_impact_risk` — **integer `0` means unset** on OCP deployments
- `business_units`, `tags`, `properties`
- `last_updated_on`, `last_updated_by`

**Type Safety Warning — Integer-Zero Criticality [VERIFIED OCP]:**
```python
# WRONG — may fail if criticality is int, and shows "0" when unset
criticality = app.get("criticality", "").lower()

# WRONG — still shows "0" in the UI
criticality = str(app.get("criticality", "")).lower()

# CORRECT — integer 0 means "not set"; normalise to empty string
def safe_criticality(value):
    if not value or value == 0 or str(value) == "0":
        return ""                  # UI renders as "—"
    return str(value).lower()

criticality  = safe_criticality(app.get("criticality"))
data_impact  = safe_criticality(app.get("data_impact_risk"))
```

**Caching:** 5 minutes (300s)

---

### GET /core/api/v1/applications/{id}
Get detailed application information.

**⚠️ OCP LIMITATION [VERIFIED OCP]:** This endpoint returns **HTTP 400** on OCP / TechZone
Concert deployments. Always implement a fallback to the list endpoint:

```python
async def get_application(client, app_id: str):
    """Fetch a single application with OCP fallback."""
    # Primary: single-app endpoint (works on SaaS, fails on OCP)
    data, from_cache = await client.get(f"/core/api/v1/applications/{app_id}")
    if data and isinstance(data, dict) and "id" in data:
        return normalize_application(data)

    # Fallback: scan the full list (required on OCP)
    list_data, _ = await client.get(
        "/core/api/v1/applications", params={"page_size": 500}
    )
    if list_data:
        for app in list_data.get("applications", []):
            if isinstance(app, dict) and app.get("id") == app_id:
                return normalize_application(app)

    return None  # not found
```

**Pydantic model must use Optional [CRITICAL]:**
```python
# WRONG — ValidationError → HTTP 500 when Concert returns 400
class ApplicationDetailResponse(BaseModel):
    application: Application

# CORRECT
from typing import Optional
class ApplicationDetailResponse(BaseModel):
    application: Optional[Application] = None
    from_cache: bool = False
```

**Response:** Single application object (no wrapper) — when available.

**Caching:** 10 minutes (600s)

---

### GET /core/api/v1/applications/{id}/vulnerability_details
Get vulnerability details for specific application.

**⚠️ OCP LIMITATION [VERIFIED OCP]:** Returns **HTTP 400** on OCP deployments.
Handle gracefully — return an empty list, not an error:

```python
data, from_cache = await client.get(
    f"/core/api/v1/applications/{app_id}/vulnerability_details"
)
if data is None:
    return VulnerabilityDetailResponse(from_cache=from_cache)  # empty, not error
vuln_list = data.get("vulnerability_details", []) or []
```

**Response Structure (when available):**
```json
{
  "vulnerability_details": [
    {
      "cve": "CVE-2024-1234",
      "highest_finding_risk_score": 9.8,
      "priority_findings": {}
    }
  ]
}
```

**Caching:** 30 minutes (1800s)

---

### GET /core/api/v1/applications/{id}/build_artifacts
Get build artifacts for application.

**Response Structure:**
```json
{
  "pagination": { "total_count": 4, "total_pages": 1, "page_size": 100, "page_number": 1 },
  "build_artifacts": [
    {
      "id": "artifact-uuid",
      "name": "docker.io/org/image",
      "image_tag": "1.0.0",
      "last_updated_on": 1787664523,
      "type": "image",
      "vulnerability_summary": { "critical": 0, "high": 5, "medium": 12 }
    }
  ]
}
```

**Date Handling — SECONDS (not milliseconds) [VERIFIED OCP]:**
```python
# API returns timestamp in SECONDS — do NOT divide by 1000
timestamp = artifact.get("last_updated_on")
if isinstance(timestamp, (int, float)):
    dt = datetime.fromtimestamp(timestamp)     # correct
    # NOT: datetime.fromtimestamp(timestamp / 1000)  ← wrong
    formatted = dt.strftime("%Y-%m-%d %H:%M")
```

**Caching:** 20 minutes (1200s)

---

### GET /core/api/v1/applications/{id}/build_artifacts/{artifact_id}/cves
Get CVEs for specific build artifact.

**Response Structure [VERIFIED OCP]:**
```json
{
  "pagination": { "total_count": 77, "total_pages": 26, "page_size": 3 },
  "cves": [
    {
      "cve": "CVE-2026-6732",
      "cvss": 7.5,
      "highest_finding_risk_score": 0.8,
      "custom_score": 0,
      "has_unassessed_findings": false,
      "unassessed_findings": 0,
      "total_findings": 1,
      "highest_finding_priority": "Deprioritized",
      "component_type": "",
      "state": "",
      "findings": null,
      "associations": { "build_artifacts": null }
    }
  ]
}
```

> ⚠️ **CRITICAL — Missing Package/Fix/Status Fields [VERIFIED OCP]:**
> On OCP deployments this endpoint does **NOT** return:
> - `package_name`
> - `package_version`
> - `fix_version`
> - `status`
>
> `findings` is always `null` and `associations.build_artifacts` is always `null`.
> These fields are absent because Concert OCP does not expose package-level CVE detail
> through this artifact endpoint. There is no `?expand=findings` parameter and no
> per-CVE sub-endpoint that returns this data (both return 404/403).
>
> **What IS reliably returned:** `cve`, `cvss`, `highest_finding_risk_score`,
> `highest_finding_priority` (string, e.g. `"Deprioritized"`), `total_findings`,
> `component_type`, `state`.
>
> **UI implication:** Do NOT display Package, Version, Fix Available, or Status
> columns in the CVE table — they will always be empty. Show Priority and Findings
> instead, and note the limitation in the table description.

**Priority Handling — String on OCP [VERIFIED OCP]:**
The `highest_finding_priority` field is a **string** on OCP (`"Deprioritized"`, `"Priority 1"`, etc.),
not an integer. Do not attempt `int()` conversion:

```python
priority = cve.get("highest_finding_priority")
priority = str(priority) if priority is not None else "N/A"
```

**Caching:** 30 minutes (1800s)

---

## Package Endpoints

### GET /core/api/v1/software_composition/packages
List all software packages. **Includes pagination wrapper [VERIFIED OCP].**

**Response Structure:**
```json
{
  "pagination": { "total_count": 106, "total_pages": 2, "page_size": 100 },
  "packages": [
    {
      "id": "pkg-uuid",
      "name": "@opentelemetry/core",
      "version": "1.30.1",
      "avg_score": 7.4375,
      "vulnerability_count": 1,
      "backlevel": false,
      "licenses": [
        {"id": "Apache-2.0", "status": "allowed"}
      ]
    }
  ]
}
```

**Critical Field Mappings:**
- Risk Score → `avg_score` (NOT `risk_score`)
- License → Extract from `licenses` array of objects

**License Extraction:**
```python
licenses = pkg.get("licenses", [])
if licenses and isinstance(licenses, list):
    license_ids = [
        str(lic.get("id"))
        for lic in licenses
        if isinstance(lic, dict) and lic.get("id")
    ]
    license_info = ", ".join(license_ids) if license_ids else "N/A"
```

**Caching:** 30 minutes (1800s)

---

### GET /core/api/v1/software_composition/recommendations
Get package upgrade recommendations.

**Real Field Names [VERIFIED OCP — supersedes earlier documentation]:**
```json
{
  "pagination": { "total_count": 68 },
  "recommendations": [
    {
      "recommendation_id": "uuid",
      "package_id": "pkg-uuid",
      "package_name": "alpine/curl",
      "package_version": "8.12.1-r1",
      "object_type": "package",
      "risk_type": "open_source",
      "action": "verify",
      "description": "The package alpine/curl is missing open-source information: avg_score.",
      "recommendation": "Review the package alpine/curl as it has missing avg_score.",
      "created_on": 1787663999,
      "updated_on": 1787663999,
      "status": "open"
    }
  ]
}
```

**Field Mapping [VERIFIED OCP — corrects earlier documentation]:**

| API field | Role | Notes |
|---|---|---|
| `recommendation_id` | Primary ID | Use this, NOT `id` |
| `description` | Human-readable reason | Why this is flagged |
| `recommendation` | Action detail | What to do about it |

Earlier docs stated `description` and `justification` were swapped — this is **incorrect**.
The real field names on OCP are `description` and `recommendation` (no `justification` field).

```python
def normalize_recommendation(raw: dict) -> Recommendation:
    rec_id = raw.get("recommendation_id") or raw.get("id", "")
    return Recommendation(
        id=str(rec_id),
        package_name=raw.get("package_name", ""),
        package_version=raw.get("package_version", ""),
        risk_type=raw.get("risk_type", ""),
        action=raw.get("action", ""),
        description=raw.get("description", ""),
        justification=raw.get("recommendation") or raw.get("justification", ""),
    )
```

**Caching:** 15 minutes (900s)

---

## Certificate Endpoints

### GET /core/api/v1/certificates
List all SSL/TLS certificates.

**Response Structure [VERIFIED OCP]:**
```json
{
  "pagination": { "total_count": 7 },
  "certificates": [
    {
      "id": "cert-uuid",
      "subject": "CN=retail-api-dev.example.com,OU=...",
      "issuer": "CN=retail-api-dev.example.com,OU=...",
      "validity_end_date": 1788220740,
      "status": "expiring soon",
      "environment": {
        "id": "env-uuid",
        "name": "retail-demo"
      }
    }
  ]
}
```

**`status` Field [VERIFIED OCP]:**
The API returns a `status` string directly on the certificate object.
**Prefer this over computing from date.** Known values: `"valid"`, `"expiring soon"`, `"expired"`.

```python
api_status = cert.get("status", "")
# Normalise to internal tokens
if "expir" in api_status.lower() and "soon" in api_status.lower():
    status = "expiring_soon"
elif "expir" in api_status.lower():
    status = "expired"
elif api_status.lower() == "valid":
    status = "valid"
else:
    status = _compute_status_from_days(days_remaining)   # fallback
```

**`validity_end_date` — Seconds vs Milliseconds [VERIFIED OCP]:**
Documentation stated milliseconds, but the live OCP API returns **seconds**.
Use a heuristic threshold to handle both:

```python
expiry = cert.get("validity_end_date")
if isinstance(expiry, (int, float)):
    if expiry > 9_999_999_999:
        dt = datetime.fromtimestamp(expiry / 1000)   # milliseconds
    else:
        dt = datetime.fromtimestamp(expiry)           # seconds (OCP)
elif isinstance(expiry, str) and len(expiry) >= 10:
    dt = datetime.fromisoformat(expiry[:19].replace("Z", ""))
```

**`environment` — Object (not string):**
```python
env = cert.get("environment")
if isinstance(env, dict):
    env_name = env.get("name") or env.get("id", "")
else:
    env_name = str(env) if env else ""
```

**Caching:** 1 hour (3600s)

---

## Error Handling Strategy

```python
def handle_concert_api_error(response, endpoint):
    """Handle Concert API errors appropriately."""
    status = response.status_code

    if status == 429:
        # Rate limited - wait and retry
        raise RateLimitError("Too many requests")

    if 400 <= status < 500:
        # Client error - log, don't retry
        # NOTE: some endpoints return 400 on OCP even for valid requests
        logger.error(f"Client error {status} for {endpoint}")
        return None

    if 500 <= status < 600:
        # Server error - retry with exponential backoff
        raise RetryableError(f"Server error: {status}")
```

---

## Resilience Checklist

- [ ] All 4 required headers included (`Accept`, `Authorization`, `InstanceID`, `Content-Type`)
- [ ] Proper header capitalization (`C_API_KEY`, not `c_api_key`)
- [ ] `InstanceID: 0000-0000-0000-0000` set for OCP deployments without a known UUID
- [ ] Connection pooling configured
- [ ] Timeouts set (5s connect, 30s read)
- [ ] Retry logic with exponential backoff (3 retries: 1s, 2s, 4s)
- [ ] Rate limiting implemented (100 req/min)
- [ ] Type checking before operations — `safe_criticality()` for integer-zero fields
- [ ] Caching with appropriate TTL per endpoint
- [ ] Comprehensive error handling
- [ ] Logging for all requests (without credentials)
- [ ] Fallback to cached data on failure
- [ ] `GET /applications/{id}` fallback to list scan (OCP returns 400)
- [ ] All Pydantic response wrapper fields typed as `Optional`
- [ ] `.env` searched in both CWD and project root
