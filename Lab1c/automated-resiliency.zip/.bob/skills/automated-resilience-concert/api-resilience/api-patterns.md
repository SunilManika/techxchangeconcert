# API Resilience Patterns

Complete implementation patterns for building resilient API integrations.

## Rate Limiter Implementation

```python
"""Token bucket rate limiter for API calls."""
import time
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import List

class RateLimiter:
    """Token bucket rate limiter."""
    
    def __init__(self, max_requests: int = 100, time_window: int = 60):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests: List[datetime] = []
        self.lock = Lock()
    
    def wait_if_needed(self):
        """Wait if rate limit would be exceeded."""
        with self.lock:
            now = datetime.now(timezone.utc)  # timezone-aware [VERIFIED OCP fix]
            cutoff = now - timedelta(seconds=self.time_window)
            self.requests = [r for r in self.requests if r > cutoff]
            
            if len(self.requests) >= self.max_requests:
                oldest = self.requests[0]
                wait_until = oldest + timedelta(seconds=self.time_window)
                sleep_time = (wait_until - now).total_seconds()
                if sleep_time > 0:
                    logger.info(f"Rate limit reached, waiting {sleep_time:.2f}s")
                    time.sleep(sleep_time)
                    self.requests.pop(0)
            
            self.requests.append(now)
```

## Resilient API Client

```python
"""Complete resilient API client with all features."""
import requests
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

class ResilientAPIClient:
    """API client with comprehensive resilience features."""
    
    def __init__(self, base_url: str, api_key: str, instance_id: str):
        self.base_url = base_url
        self.session = requests.Session()
        self.rate_limiter = RateLimiter(max_requests=100, time_window=60)
        
        # Configure session headers
        self.session.headers.update({
            "Accept": "application/json",
            "Authorization": f"C_API_KEY {api_key}",
            "InstanceID": instance_id,
            "Content-Type": "application/json"
        })
    
    def make_request(
        self,
        endpoint: str,
        method: str = "GET",
        max_retries: int = 3,
        **kwargs
    ) -> Optional[Dict[str, Any]]:
        """Make resilient API request with retry logic."""
        url = f"{self.base_url}{endpoint}"
        
        for attempt in range(max_retries):
            try:
                # Rate limiting
                self.rate_limiter.wait_if_needed()
                
                # Make request
                response = self.session.request(
                    method,
                    url,
                    timeout=(5, 30),
                    **kwargs
                )
                
                # Handle specific status codes
                if response.status_code == 429:
                    wait_time = 2 ** attempt
                    logger.warning(f"Rate limited, waiting {wait_time}s")
                    time.sleep(wait_time)
                    continue
                
                response.raise_for_status()
                return response.json()
                
            except requests.exceptions.Timeout as e:
                logger.warning(f"Timeout on attempt {attempt + 1}: {e}")
                if attempt == max_retries - 1:
                    logger.error(f"Failed after {max_retries} timeouts")
                    return None
                    
            except requests.exceptions.RequestException as e:
                logger.error(f"Request failed on attempt {attempt + 1}: {e}")
                if attempt == max_retries - 1:
                    return None
                wait_time = 2 ** attempt
                time.sleep(wait_time)
        
        return None
```

## Type-Safe Data Handling

```python
"""Handle API responses with type safety."""

def safe_string_operation(value: Any) -> str:
    """Safely convert to string before operations."""
    return str(value).lower() if value else ""

def safe_criticality(value: Any) -> str:
    """
    OCP Concert deployments return criticality as integer 0 when unset.
    Treat 0 as empty string so UI renders dash instead of '0'.
    [VERIFIED OCP]
    """
    if not value or value == 0 or str(value) == "0":
        return ""
    return str(value).lower()

def safe_date_parsing(date_value: Any) -> Optional[datetime]:
    """
    Parse date handling multiple formats.
    Uses > 9_999_999_999 heuristic to distinguish ms from s timestamps.
    [VERIFIED OCP: validity_end_date is SECONDS, not milliseconds]
    """
    if isinstance(date_value, int):
        if date_value > 9_999_999_999:
            return datetime.fromtimestamp(date_value / 1000)  # milliseconds
        return datetime.fromtimestamp(date_value)              # seconds
    elif isinstance(date_value, str):
        try:
            return datetime.fromisoformat(date_value.replace('Z', '+00:00'))
        except ValueError:
            logger.warning(f"Invalid date format: {date_value}")
            return None
    return None

def safe_get_nested(data: Dict, *keys, default=None):
    """Safely get nested dictionary values."""
    for key in keys:
        if isinstance(data, dict):
            data = data.get(key)
            if data is None:
                return default
        else:
            return default
    return data
```

## Circuit Breaker Pattern

```python
"""Circuit breaker for failing services."""
from enum import Enum
from datetime import datetime, timedelta, timezone

class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

class CircuitBreaker:
    """Circuit breaker to prevent cascading failures."""
    
    def __init__(self, failure_threshold: int = 5, timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failure_count = 0
        self.last_failure_time = None
        self.state = CircuitState.CLOSED
    
    def call(self, func, *args, **kwargs):
        """Execute function with circuit breaker protection."""
        if self.state == CircuitState.OPEN:
            if datetime.now(timezone.utc) - self.last_failure_time > timedelta(seconds=self.timeout):
                self.state = CircuitState.HALF_OPEN
            else:
                raise Exception("Circuit breaker is OPEN")
        
        try:
            result = func(*args, **kwargs)
            self.on_success()
            return result
        except Exception as e:
            self.on_failure()
            raise e
    
    def on_success(self):
        """Reset on successful call."""
        self.failure_count = 0
        self.state = CircuitState.CLOSED
    
    def on_failure(self):
        """Handle failure."""
        self.failure_count += 1
        self.last_failure_time = datetime.now(timezone.utc)  # timezone-aware
        
        if self.failure_count >= self.failure_threshold:
            self.state = CircuitState.OPEN
            logger.error("Circuit breaker opened due to failures")
```

## Caching Strategy

```python
"""Multi-level caching implementation."""
from functools import wraps
import time

def cached_api_call(ttl: int = 300):
    """Decorator for caching API calls."""
    cache = {}
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key
            key = f"{func.__name__}:{args}:{kwargs}"
            
            # Check cache
            if key in cache:
                value, timestamp = cache[key]
                if time.time() - timestamp < ttl:
                    logger.debug(f"Cache hit for {func.__name__}")
                    return value
            
            # Call function
            result = func(*args, **kwargs)
            cache[key] = (result, time.time())
            logger.debug(f"Cache miss for {func.__name__}")
            return result
        
        return wrapper
    return decorator

# Usage
@cached_api_call(ttl=300)
def get_applications():
    return client.make_request("/core/api/v1/applications")
```

## OCP Deployment Patterns [VERIFIED against live Concert OCP / TechZone]

### Circuit Breaker — Use Timezone-Aware Datetimes
```python
from datetime import datetime, timezone

# WRONG — mixing naive and aware datetimes causes TypeError on comparison
self.last_failure_time = datetime.utcnow()          # naive UTC

# CORRECT — always use timezone-aware
self.last_failure_time = datetime.now(timezone.utc) # aware UTC

# Comparison also must be aware
if datetime.now(timezone.utc) - self.last_failure_time > timedelta(seconds=60):
    self.state = CircuitState.HALF_OPEN
```

### .env File Discovery for Subdirectory Startup
When `uvicorn` starts from `backend/`, `env_file=".env"` only looks in CWD.
Search both CWD and project root so credentials are found in all cases:

```python
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

def _find_env_file() -> list[str]:
    """Return .env paths to try in priority order (CWD first, then project root)."""
    cwd_env    = Path(".env")
    parent_env = Path(__file__).parent.parent.parent.parent / ".env"  # adjust depth
    paths = []
    if cwd_env.exists():
        paths.append(str(cwd_env))
    if parent_env.exists() and parent_env.resolve() != cwd_env.resolve():
        paths.append(str(parent_env))
    return paths if paths else [".env"]

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=_find_env_file(),
        env_file_encoding="utf-8",
    )
```

### Optional Pydantic Response Fields — Prevent HTTP 500 on Empty Data
```python
from typing import Optional
from pydantic import BaseModel

# WRONG — Pydantic raises ValidationError if Concert returns 400/empty → HTTP 500
class ApplicationDetailResponse(BaseModel):
    application: Application

# CORRECT — graceful null, route returns empty response instead of crashing
class ApplicationDetailResponse(BaseModel):
    application: Optional[Application] = None
    from_cache: bool = False

# Defensive service pattern
async def get_application(client, app_id: str) -> ApplicationDetailResponse:
    data, from_cache = await client.get(f"/core/api/v1/applications/{app_id}")
    if data is not None and isinstance(data, dict) and "id" in data:
        return ApplicationDetailResponse(
            application=normalize_application(data), from_cache=from_cache
        )
    # Fallback: scan list endpoint (required on OCP — single-app returns 400)
    list_data, list_cache = await client.get(
        "/core/api/v1/applications", params={"page_size": 500}
    )
    if list_data:
        for app_raw in list_data.get("applications", []):
            if isinstance(app_raw, dict) and app_raw.get("id") == app_id:
                return ApplicationDetailResponse(
                    application=normalize_application(app_raw), from_cache=list_cache
                )
    return ApplicationDetailResponse(application=None, from_cache=from_cache)
```

---

