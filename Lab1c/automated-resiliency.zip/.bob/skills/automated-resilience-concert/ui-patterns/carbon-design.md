# IBM Carbon Design System UI Patterns

Complete, production-verified reference for building the Automated Resiliency & Security Insights dashboard
with IBM Carbon Design System. Every pattern here was extracted from the **live, working dashboard** and
represents the canonical way to implement each UI element.

---

## Stack and Dependencies

```json
{
  "dependencies": {
    "@carbon/react":        "^1.68.0",
    "@carbon/styles":       "^1.68.0",
    "@carbon/icons-react":  "^11.40.0",
    "@carbon/charts-react": "^1.23.0",
    "@carbon/charts":       "^1.23.0",
    "react":                "^18.3.1",
    "react-dom":            "^18.3.1"
  },
  "devDependencies": {
    "vite":                 "^5.3.4",
    "@vitejs/plugin-react": "^4.3.1",
    "typescript":           "^5.5.3"
  }
}
```

**Entry point — load Carbon styles globally in `main.tsx`:**

```tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';          // IBM Plex Sans + CSS token overrides (see Global CSS below)
import App from './App';

// In App.tsx:
import '@carbon/styles/css/styles.css';  // must be first Carbon import
```

---

## Global CSS (`src/index.css`)

```css
/* IBM Plex Sans — 3 weights used: 300 (display values), 400 (body), 600 (labels) */
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;600&display=swap');

*, *::before, *::after { box-sizing: border-box; }

html, body {
  margin: 0;
  padding: 0;
  font-family: 'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif;
  font-size: 16px;
  background-color: #f4f4f4;   /* Carbon Gray 10 — page background */
  color: #161616;               /* Carbon Gray 100 — default text */
  -webkit-font-smoothing: antialiased;
}

/* Carbon header z-index — above all content */
.cds--header { z-index: 9000; }

/* Carbon Grid — full width (no default max-width cap) */
.cds--grid { max-width: 100%; }

/* Tiles — always white, no border-radius */
.cds--tile { background-color: #ffffff; border-radius: 0; }

/* DataTable — flush top */
.cds--data-table-container { padding-top: 0; }

/* Carbon Charts — no default card border */
.cds--cc--chart-wrapper { border: none; }

/* Pagination — flush with table bottom */
.cds--pagination { border-top: 1px solid #e0e0e0; }

/* InlineNotification — always full-width */
.cds--inline-notification { max-width: 100%; }

/* Breadcrumb current page — not a link */
.cds--breadcrumb-item:last-child .cds--link { cursor: default; color: #161616; }

/* StructuredList — tighter row padding */
.cds--structured-list-td,
.cds--structured-list-th { padding-block: 0.5rem; }
```

---

## Colour Tokens

All hex values map to official Carbon v11 tokens:

| Role | Hex | Carbon token |
|---|---|---|
| Interactive blue | `#0f62fe` | `$interactive` / Blue-60 |
| Red / Critical | `#da1e28` | `$support-error` / Red-60 |
| Orange / High risk | `#ff832b` | Orange-40 |
| Yellow / Medium | `#f1c21b` | Yellow-30 |
| Green / Valid | `#24a148` | `$support-success` / Green-50 |
| Purple / SCA | `#8a3ffc` | Purple-60 |
| Teal / Certificates | `#009d9a` | Teal-50 |
| Page background | `#f4f4f4` | `$layer-01` / Gray-10 |
| Tile background | `#ffffff` | `$layer-02` / White |
| Dark header bg | `#161616` | `$background` / Gray-100 |
| Header border | `#393939` | Gray-70 |
| Muted text | `#6f6f6f` | `$text-secondary` / Gray-50 |
| Selection tint | `#edf5ff` | Blue-10 |
| Blue link / icon | `#78a9ff` | Blue-40 (on dark) |
| Gray text | `#8d8d8d` | Gray-50 |
| Border | `#e0e0e0` | `$border-subtle-01` / Gray-20 |

---

## App Shell (`AppShell.tsx`)

The entire app is wrapped in `<Theme theme="g100">` so the Carbon Header renders dark
while the content area is light.

```tsx
import {
  Header, HeaderName, HeaderNavigation, HeaderMenuItem,
  HeaderGlobalBar, HeaderGlobalAction, SkipToContent, Theme,
} from '@carbon/react';
import { Security, Dashboard, Certificate, Switcher, IbmWatsonDiscovery } from '@carbon/icons-react';

export function AppShell({ activeTab, onTabChange, children }) {
  return (
    <Theme theme="g100">
      <SkipToContent />

      {/* ── Fixed dark header ── */}
      <Header aria-label="Automated Resiliency and Security Insights — IBM Concert">
        <HeaderName href="#" prefix="IBM">
          Resiliency &amp; Security Insights
        </HeaderName>
        <HeaderNavigation aria-label="Primary navigation">
          {NAV_ITEMS.map(({ id, label }) => (
            <HeaderMenuItem
              key={id}
              isCurrentPage={activeTab === id}
              onClick={() => onTabChange(id)}
              href="#"
            >
              {label}
            </HeaderMenuItem>
          ))}
        </HeaderNavigation>
        <HeaderGlobalBar>
          <HeaderGlobalAction aria-label="Powered by IBM Concert" tooltipAlignment="end">
            <IbmWatsonDiscovery size={20} />
          </HeaderGlobalAction>
        </HeaderGlobalBar>
      </Header>

      {/* ── Subheader context band ── */}
      {/* marginTop: '3rem' pushes below the fixed 48px header */}
      <div style={{
        marginTop: '3rem',
        background: '#161616',
        borderBottom: '1px solid #393939',
        padding: '0.625rem 1rem',
        display: 'flex', alignItems: 'center', gap: '0.75rem',
      }}>
        <IbmWatsonDiscovery size={20} style={{ color: '#78a9ff', flexShrink: 0 }} />
        <div>
          <p style={{ color: '#f4f4f4', fontSize: '0.875rem', fontWeight: 600, lineHeight: 1.2, margin: 0 }}>
            Automated Resiliency &amp; Security Insights
          </p>
          <p style={{ color: '#8d8d8d', fontSize: '0.75rem', margin: 0 }}>
            Powered by IBM Bob &amp; IBM Concert • Real-time data
          </p>
        </div>
        {/* Active-tab pill — Blue-60 background */}
        <span style={{
          marginLeft: 'auto',
          background: '#0f62fe', color: '#fff',
          fontSize: '0.6875rem', fontWeight: 600,
          padding: '0.125rem 0.625rem',
          borderRadius: '0.75rem',
          letterSpacing: '0.02em', textTransform: 'uppercase',
        }}>
          {NAV_ITEMS.find(n => n.id === activeTab)?.label ?? ''}
        </span>
      </div>

      {/* ── Light content area ── */}
      <main id="main-content" style={{ minHeight: 'calc(100vh - 3rem - 2.5rem)', background: '#f4f4f4' }}>
        {children}
      </main>

      {/* ── Dark footer ── */}
      <footer style={{
        background: '#161616', borderTop: '1px solid #393939',
        padding: '0.75rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem',
      }}>
        <IbmWatsonDiscovery size={16} style={{ color: '#78a9ff' }} />
        <p style={{ color: '#6f6f6f', fontSize: '0.75rem', margin: 0 }}>
          IBM Concert API Integration — IBM Carbon Design System — IBM Bob
        </p>
      </footer>
    </Theme>
  );
}
```

**Nav item icon mapping (verified exported names from `@carbon/icons-react` v11):**

| Tab | Icon |
|---|---|
| App Security | `Security` |
| Vulnerabilities | `Dashboard` |
| Software Composition | `IbmWatsonDiscovery` |
| Certificates | `Certificate` |
| System Health | `Switcher` |

> ⚠️  Icons `Health`, `Software`, and `PackageImport` do NOT exist in `@carbon/icons-react` v11.
> Use `Switcher`, `Application`, and `Download` respectively.

---

## Page Header Pattern

Every dashboard tab opens with an identical header layout. Apply it consistently.

```tsx
import { Button } from '@carbon/react';
import { Security, Renew } from '@carbon/icons-react';

{/* ── Page header ── */}
<div style={{
  display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
  marginBottom: '1.5rem',
  paddingBottom: '1rem',
  borderBottom: '1px solid #e0e0e0',
}}>
  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
    {/* Coloured circle icon — use semantic accent colour per tab */}
    <div style={{
      background: '#0f62fe',          /* Tab accent colour */
      borderRadius: '50%',
      width: '2.5rem', height: '2.5rem',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>
      <Security size={20} style={{ color: '#fff' }} />
    </div>
    <div>
      {/* h1 — Carbon expressive: light weight, IBM Plex Sans */}
      <h1 style={{
        fontSize: '1.5rem', fontWeight: 300, color: '#161616',
        margin: 0, fontFamily: '"IBM Plex Sans", sans-serif',
      }}>
        Application Security
      </h1>
      <p style={{ fontSize: '0.875rem', color: '#6f6f6f', margin: 0 }}>
        IBM Concert • Auto-refreshes every 60s • Last updated 14:32:01
      </p>
    </div>
  </div>

  {/* Right-aligned Refresh button */}
  <Button kind="tertiary" size="sm" renderIcon={Renew} iconDescription="Refresh" onClick={refresh}>
    Refresh
  </Button>
</div>
```

**Tab accent colours:**

| Tab | Circle colour |
|---|---|
| App Security | `#0f62fe` (blue) |
| Vulnerability Drill-Through | `#da1e28` (red) |
| Software Composition | `#8a3ffc` (purple) |
| Certificate Management | `#009d9a` (teal) |
| System Health | `#0f62fe` (blue) |

---

## KPI Tile (`KpiTile.tsx`)

Reusable metric tile with semantic `borderTop` accent, optional icon, skeleton loading.

```tsx
import { Tile, SkeletonText } from '@carbon/react';

type Accent = 'default' | 'red' | 'orange' | 'green' | 'blue' | 'purple' | 'teal';

const ACCENT_COLORS: Record<Accent, string> = {
  default: '#0f62fe',
  red:     '#da1e28',
  orange:  '#ff832b',
  green:   '#24a148',
  blue:    '#0f62fe',
  purple:  '#8a3ffc',
  teal:    '#009d9a',
};

interface KpiTileProps {
  label: string;
  value: string | number;
  loading?: boolean;
  accent?: Accent;
  subLabel?: string;
  icon?: React.ReactNode;   // Carbon icon, sized 20, rendered at accent colour
}

export function KpiTile({ label, value, loading, subLabel, accent = 'default', icon }: KpiTileProps) {
  const accentColor = ACCENT_COLORS[accent];
  return (
    <Tile style={{
      height: '100%', minHeight: '6.5rem',
      borderTop: `3px solid ${accentColor}`,
      padding: '1rem', background: '#ffffff',
    }}>
      {loading ? (
        <>
          <SkeletonText width="50%" />
          <SkeletonText heading width="35%" />
        </>
      ) : (
        <>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            {/* Label — uppercase micro-type */}
            <p style={{
              fontSize: '0.6875rem', fontWeight: 600,
              color: '#6f6f6f', letterSpacing: '0.08em',
              textTransform: 'uppercase', margin: 0,
            }}>
              {label}
            </p>
            {/* Optional icon in accent colour */}
            {icon && <span style={{ color: accentColor, flexShrink: 0, marginLeft: '0.5rem' }}>{icon}</span>}
          </div>

          {/* Value — Carbon expressive display weight */}
          <p style={{
            fontSize: '2rem', fontWeight: 300, lineHeight: 1.1,
            color: '#161616', marginTop: '0.375rem', marginBottom: 0,
            fontFamily: '"IBM Plex Sans", sans-serif',
          }}>
            {value}
          </p>

          {/* Sub-label */}
          {subLabel && (
            <p style={{ fontSize: '0.75rem', color: '#6f6f6f', marginTop: '0.25rem', marginBottom: 0 }}>
              {subLabel}
            </p>
          )}
        </>
      )}
    </Tile>
  );
}
```

**KPI accent colour guide:**

| KPI meaning | Accent |
|---|---|
| Total / neutral count | `blue` |
| Critical / expired / error | `red` |
| High risk / expiring soon | `orange` |
| Valid / healthy / success | `green` |
| SCA / packages | `purple` |
| Cache / teal metrics | `teal` |

---

## Data Fetch Notification (`DataFetchNotification.tsx`)

Inline banners for API errors and cache hits. Always `lowContrast` and `hideCloseButton`.

```tsx
import { InlineNotification } from '@carbon/react';

export function DataFetchNotification({ fromCache, error, lastUpdated }) {
  if (error) {
    return (
      <InlineNotification
        kind="error"
        title="Data unavailable"
        subtitle={
          lastUpdated
            ? `Showing cached data from ${lastUpdated.toLocaleTimeString()}. ${error}`
            : `Unable to fetch data. ${error}`
        }
        lowContrast
        hideCloseButton
        style={{ marginBottom: '1rem', maxWidth: '100%' }}
      />
    );
  }
  if (fromCache) {
    return (
      <InlineNotification
        kind="info"
        title="Serving cached data"
        subtitle={lastUpdated ? `Last refreshed at ${lastUpdated.toLocaleTimeString()}` : ''}
        lowContrast
        hideCloseButton
        style={{ marginBottom: '1rem', maxWidth: '100%' }}
      />
    );
  }
  return null;
}
```

---

## Tag Patterns

Carbon `<Tag>` maps domain values to the available type set. Always `size="sm"` in tables.

```tsx
import { Tag } from '@carbon/react';

// ── Severity (CVE / vulnerability) ──
const SEV_TAG_TYPE = {
  critical: 'red',
  high:     'magenta',
  medium:   'teal',
  low:      'cyan',
  none:     'cool-gray',
} as const;

function SeverityTag({ severity }: { severity: string }) {
  const type = SEV_TAG_TYPE[(severity || '').toLowerCase()] ?? 'cool-gray';
  return <Tag type={type} size="sm">{severity || 'N/A'}</Tag>;
}

// ── Application criticality ──
const CRIT_TAG_TYPE = {
  critical: 'red',
  high:     'magenta',
  medium:   'purple',
  low:      'cool-gray',
} as const;

// ── Certificate status ──
const CERT_TAG_TYPE = {
  expired:       'red',
  expiring_soon: 'teal',
  valid:         'green',
} as const;
const CERT_TAG_LABEL = {
  expired:       'Expired',
  expiring_soon: 'Expiring Soon',
  valid:         'Valid',
} as const;

function CertStatusTag({ status }) {
  return <Tag type={CERT_TAG_TYPE[status] ?? 'cool-gray'} size="sm">
    {CERT_TAG_LABEL[status] ?? status}
  </Tag>;
}

// ── Build artifact image tag ──
<Tag type="blue" size="sm">{artifact.image_tag}</Tag>

// ── Vulnerability count on package row ──
pkg.vulnerability_count > 0
  ? <Tag type="red"   size="sm">{pkg.vulnerability_count}</Tag>
  : <Tag type="green" size="sm">0</Tag>
```

> ⚠️  Carbon has **no `orange` Tag type**. Use `type="teal"` for "expiring soon" or use a
> colour-coded `<span>` for numeric cells. See `DaysRemainingCell` below.

---

## Colour-coded Text Cell (no Tag)

For numeric cells where semantic colour matters more than a badge shape:

```tsx
// Certificate days-remaining column
function DaysRemainingCell({ days }: { days: number }) {
  const text = formatDaysRemaining(days);
  let color = '#161616';
  if (days < 0)        color = '#da1e28';  // expired    → red
  else if (days <= 7)  color = '#da1e28';  // ≤ 7 days   → red
  else if (days <= 30) color = '#ff832b';  // ≤ 30 days  → orange
  else                 color = '#24a148';  // > 30 days  → green
  return <span style={{ color, fontWeight: 600, fontSize: '0.875rem' }}>{text}</span>;
}
```

---

## Carbon DataTable — Full Pattern

Every sortable, searchable table follows this template exactly.

```tsx
import {
  DataTable, Table, TableHead, TableRow, TableHeader, TableBody, TableCell,
  TableContainer, TableToolbar, TableToolbarContent, TableToolbarSearch,
  SkeletonText, Pagination,
} from '@carbon/react';

// 1. Define headers array outside the component
const TABLE_HEADERS = [
  { key: 'name',    header: 'Application'    },
  { key: 'version', header: 'Version'        },
  { key: 'actions', header: ''               },  // action column — no label
];

// 2. Build rows (JSX allowed as cell values)
const tableRows = data.map(item => ({
  id:      item.id,                          // required — must be a string
  name:    item.name,
  version: item.version || '—',
  actions: <Button kind="ghost" size="sm" renderIcon={ArrowRight} ...>Drill Through</Button>,
}));

// 3. Render
<DataTable rows={tableRows} headers={TABLE_HEADERS} isSortable>
  {({ rows, headers, getHeaderProps, getRowProps, getTableProps,
      getToolbarProps, getTableContainerProps }) => (
    <TableContainer
      title="Applications"
      description={`${filteredData.length} items`}
      {...getTableContainerProps()}
    >
      <TableToolbar {...getToolbarProps()}>
        <TableToolbarContent>
          {/* Always TableToolbarSearch — never raw <input> */}
          <TableToolbarSearch
            placeholder="Search…"
            onChange={(_e, value?) => { setSearch(value ?? ''); setPage(1); }}
            persistent
          />
        </TableToolbarContent>
      </TableToolbar>

      {loading ? (
        <div style={{ padding: '2rem' }}><SkeletonText paragraph lineCount={6} /></div>
      ) : (
        <Table {...getTableProps()} size="md" useZebraStyles>
          <TableHead>
            <TableRow>
              {headers.map(header => (
                // @ts-expect-error carbon generic types
                <TableHeader key={header.key} {...getHeaderProps({ header })}
                             isSortable={header.key !== 'actions'}>
                  {header.header}
                </TableHeader>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map(row => (
              // @ts-expect-error carbon generic types
              <TableRow key={row.id} {...getRowProps({ row })}>
                {row.cells.map(cell => (
                  <TableCell key={cell.id}>{cell.value}</TableCell>
                ))}
              </TableRow>
            ))}
            {rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={TABLE_HEADERS.length}
                           style={{ textAlign: 'center', padding: '2rem', color: '#6f6f6f' }}>
                  No items found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      )}
    </TableContainer>
  )}
</DataTable>

{/* Pagination below the table — only when needed */}
{filteredData.length > pageSize && (
  <Pagination
    totalItems={filteredData.length}
    pageSize={pageSize}
    pageSizes={[10, 20, 50, 100]}
    page={page}
    onChange={({ page: p, pageSize: ps }) => { setPage(p); setPageSize(ps); }}
  />
)}
```

### Active-row selection highlight

When a row is "selected" (e.g. a package whose details panel is open):

```tsx
// Destructure key out of getRowProps to avoid duplicate-key TS error
const { key: _k, ...rowProps } = getRowProps({ row }) as { key: string; [k: string]: unknown };
return (
  <TableRow
    key={row.id}
    {...(rowProps as object)}
    style={{
      background: isSelected ? '#edf5ff' : undefined,             // Blue-10 tint
      borderLeft: isSelected ? '3px solid #0f62fe' : '3px solid transparent',
    }}
  >
    ...
  </TableRow>
);
```

---

## Carbon Charts — Inside a Tile

All charts live inside a `<Tile>` with a section-label above. Never in a bare `<div>`.

```tsx
import { SimpleBarChart, DonutChart, LineChart } from '@carbon/charts-react';
import { ScaleTypes } from '@carbon/charts';
import '@carbon/charts-react/styles.css';  // must be imported once per page
import { Tile } from '@carbon/react';

{/* ── Section label (same style everywhere) ── */}
const CHART_LABEL_STYLE = {
  fontSize: '0.6875rem', fontWeight: 600 as const,
  letterSpacing: '0.08em', textTransform: 'uppercase' as const,
  color: '#6f6f6f', marginBottom: '0.75rem',
};

{/* ── SimpleBarChart (severity / top packages) ── */}
<Tile style={{ padding: '1rem', background: '#fff' }}>
  <p style={CHART_LABEL_STYLE}>Finding Distribution by Severity</p>
  <SimpleBarChart
    data={chartData}   // [{ group: 'Critical', value: 12 }, ...]
    options={{
      title: '',
      axes: {
        left:   { mapsTo: 'value', title: 'Count' },
        bottom: { mapsTo: 'group', scaleType: ScaleTypes.LABELS },
      },
      color: {
        scale: {
          Critical: '#da1e28',
          High:     '#ff832b',
          Medium:   '#f1c21b',
          Low:      '#0f62fe',
        },
      },
      height: '220px',
      toolbar: { enabled: false },   // always disable floating toolbar
    }}
  />
</Tile>

{/* ── DonutChart (CVE severity / certificate status) ── */}
<Tile style={{ padding: '1rem', background: '#fff' }}>
  <p style={CHART_LABEL_STYLE}>CVE Severity Distribution</p>
  <DonutChart
    data={donutData}   // [{ group: 'Critical', value: 5 }, ...]
    options={{
      title: '',
      resizable: true,
      height: '220px',
      donut: { center: { label: 'CVEs', number: totalCves } },
      color: { scale: { Critical: '#da1e28', High: '#ff832b', Medium: '#f1c21b', Low: '#0f62fe' } },
      toolbar: { enabled: false },
    }}
  />
</Tile>

{/* ── LineChart (performance trends) ── */}
<Tile style={{ padding: '1rem', background: '#fff' }}>
  <p style={CHART_LABEL_STYLE}>Performance Trends</p>
  <LineChart
    data={metricHistory}   // [{ group: 'Response Time (ms)', date: new Date(), value: 120 }, ...]
    options={{
      title: '',
      axes: {
        bottom: { title: 'Time', mapsTo: 'date', scaleType: ScaleTypes.TIME },
        left:   { mapsTo: 'value', title: 'Value' },
      },
      curve: 'curveMonotoneX',
      height: '220px',
      toolbar: { enabled: false },
    }}
  />
</Tile>
```

---

## Buttons — `renderIcon` Pattern

Always use `renderIcon` for buttons with icons. Never wrap icon+text manually.

```tsx
import { Button } from '@carbon/react';
import { Renew, ArrowRight, ArrowLeft, IbmSecurity, Close,
         ListBulleted, Information, Download, CheckmarkFilled } from '@carbon/icons-react';

{/* Text + trailing icon */}
<Button kind="tertiary" size="sm" renderIcon={Renew} iconDescription="Refresh" onClick={refresh}>
  Refresh
</Button>

{/* Ghost action button in table cell */}
<Button kind="ghost" size="sm" renderIcon={ArrowRight} iconDescription="View details" onClick={...}>
  Drill Through
</Button>

{/* Icon-only button (hasIconOnly — no text rendered) */}
<Button kind="ghost" size="sm" hasIconOnly renderIcon={Close} iconDescription="Close" onClick={...} />

{/* Secondary with icon */}
<Button kind="secondary" size="sm" renderIcon={ListBulleted} iconDescription="Recommendations" onClick={...}>
  Recommendations (68)
</Button>
```

---

## InlineNotification

Use for proactive alerts (certificate expiry, API errors, cached data). Always `lowContrast`.

```tsx
import { InlineNotification } from '@carbon/react';

{/* Error — expired certs, API down */}
<InlineNotification
  kind="error"
  title="7 expired certificates — "
  subtitle="Immediate renewal required"
  lowContrast
  hideCloseButton
  style={{ marginBottom: '0.5rem', maxWidth: '100%' }}
/>

{/* Warning — expiring soon, degraded */}
<InlineNotification kind="warning" title="12 certs expiring within 30 days — " subtitle="..." lowContrast hideCloseButton />

{/* Info — cached data */}
<InlineNotification kind="info" title="Serving cached data" subtitle="Last refreshed at 14:32:01" lowContrast hideCloseButton />

{/* Success — no issues */}
<InlineNotification kind="success" title="No upgrade recommendations" subtitle="..." lowContrast hideCloseButton />
```

**Ordering rule:** Error alerts always render above warning alerts above info banners.

---

## Breadcrumb Navigation

Used in the Vulnerability Drill-Through to track the navigation path.

```tsx
import { Breadcrumb, BreadcrumbItem } from '@carbon/react';

<Breadcrumb style={{ marginBottom: '1.5rem' }}>
  <BreadcrumbItem onClick={onBack} href="#">
    App Security
  </BreadcrumbItem>
  <BreadcrumbItem
    href="#"
    isCurrentPage={!selectedArtifact}
    onClick={() => setSelectedArtifact(null)}
  >
    {app?.name ?? appId}
  </BreadcrumbItem>
  {selectedArtifact && (
    <BreadcrumbItem isCurrentPage>
      {selectedArtifact.name || selectedArtifact.id}
    </BreadcrumbItem>
  )}
</Breadcrumb>
```

---

## StructuredList — Detail Panels

Used for key-value detail panels (application details, connectivity status, package details).

> ⚠️ **Always set `color: '#161616'` on the value `StructuredListCell`.**
> Carbon's default text token renders as near-invisible on non-white tile backgrounds
> (`#edf5ff` Blue-10, coloured `borderLeft` tiles, etc.). The label cell uses `#6f6f6f`
> intentionally (muted); the value cell must always be pinned to `#161616` (Gray 100).

```tsx
import { Tile, StructuredListWrapper, StructuredListBody,
         StructuredListRow, StructuredListCell } from '@carbon/react';
import { DocumentSecurity } from '@carbon/icons-react';

<Tile style={{ background: '#fff', borderLeft: '3px solid #0f62fe' }}>
  {/* Section icon + label */}
  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
    <DocumentSecurity size={20} style={{ color: '#0f62fe' }} />
    <p style={{
      fontSize: '0.6875rem', fontWeight: 600, letterSpacing: '0.08em',
      textTransform: 'uppercase', color: '#6f6f6f', margin: 0,
    }}>
      Application Details
    </p>
  </div>

  <StructuredListWrapper isCondensed>
    <StructuredListBody>
      {[
        ['Name',         app?.name],
        ['Version',      app?.version      || '—'],
        ['Criticality',  app?.criticality  || '—'],
        ['Last Updated', app?.last_updated_on || '—'],
      ].map(([label, value]) => (
        <StructuredListRow key={label as string}>
          {/* Label — intentionally muted */}
          <StructuredListCell noWrap style={{ color: '#6f6f6f', width: '40%' }}>
            {label}
          </StructuredListCell>
          {/* Value — MUST pin color: '#161616' or text is invisible on tinted tiles */}
          <StructuredListCell style={{ fontWeight: 500, color: '#161616' }}>{value}</StructuredListCell>
        </StructuredListRow>
      ))}
    </StructuredListBody>
  </StructuredListWrapper>
</Tile>
```

---

## Status Icons (System Health)

Map health status strings to filled Carbon icons with semantic colours.

```tsx
import { CheckmarkFilled, WarningFilled, ErrorFilled, Activity } from '@carbon/icons-react';

function StatusIcon({ status }: { status: string }) {
  const s = (status || '').toLowerCase();
  if (s === 'healthy')   return <CheckmarkFilled size={20} style={{ color: '#24a148' }} />;
  if (s === 'degraded')  return <WarningFilled   size={20} style={{ color: '#ff832b' }} />;
  if (s === 'unhealthy') return <ErrorFilled     size={20} style={{ color: '#da1e28' }} />;
  return <Activity size={20} style={{ color: '#8d8d8d' }} />;
}

{/* Component status tile — borderTop accent matches status colour */}
<Tile style={{
  background: '#fff',
  borderTop: `3px solid ${
    comp.status === 'healthy'   ? '#24a148' :
    comp.status === 'degraded'  ? '#ff832b' :
    comp.status === 'unhealthy' ? '#da1e28' : '#8d8d8d'
  }`,
}}>
  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.75rem' }}>
    <StatusIcon status={comp.status} />
    <p style={{ fontSize: '0.6875rem', fontWeight: 600, letterSpacing: '0.08em',
                textTransform: 'uppercase', color: '#6f6f6f', margin: 0 }}>
      {name.replace(/_/g, ' ')}
    </p>
  </div>
  <StatusTag status={comp.status} />
  ...
</Tile>
```

---

## Carbon Modal

Used for the Recommendations overlay in Software Composition.

```tsx
import { Modal } from '@carbon/react';

<Modal
  open={showRecModal}
  modalHeading="Package Upgrade Recommendations"
  passiveModal                            // no primary/secondary action buttons
  onRequestClose={() => setShowRecModal(false)}
  size="lg"
>
  <p style={{ fontSize: '0.875rem', color: '#6f6f6f', marginBottom: '1rem' }}>
    Showing all recommendations from IBM Concert.
  </p>
  {/* DataTable inside Modal body */}
  <DataTable rows={recRows} headers={REC_HEADERS}>
    {({ rows, headers, getHeaderProps, getRowProps, getTableProps }) => (
      <Table {...getTableProps()} size="sm" useZebraStyles>
        ...
      </Table>
    )}
  </DataTable>
</Modal>
```

---

## Grid Layout

Use the Carbon `narrow` grid for all dashboard layouts.

```tsx
import { Grid, Column } from '@carbon/react';

{/* ── 4-column KPI row ── */}
<Grid narrow style={{ marginBottom: '1.5rem' }}>
  <Column sm={1} md={2} lg={3}><KpiTile ... /></Column>
  <Column sm={1} md={2} lg={3}><KpiTile ... /></Column>
  <Column sm={1} md={2} lg={3}><KpiTile ... /></Column>
  <Column sm={1} md={2} lg={3}><KpiTile ... /></Column>
</Grid>

{/* ── Chart + summary side-by-side ── */}
<Grid narrow style={{ marginBottom: '1.5rem' }}>
  <Column sm={4} md={5} lg={6}>{/* chart */}</Column>
  <Column sm={4} md={3} lg={4}>{/* top-5 list */}</Column>
</Grid>

{/* ── Detail tile + KPIs ── */}
<Grid narrow style={{ marginBottom: '1.5rem' }}>
  <Column sm={4} md={4} lg={5}>{/* StructuredList detail panel */}</Column>
  <Column sm={4} md={4} lg={7}>{/* nested Grid with KPI tiles */}</Column>
</Grid>
```

---

## Utility Helpers (`src/utils/format.ts`)

Shared colour and formatting helpers used across all components.

```ts
/** Carbon severity colour tokens (for chart scale objects) */
export const SEVERITY_COLORS = {
  critical: '#da1e28',  // red-60
  high:     '#ff832b',  // orange-40
  medium:   '#f1c21b',  // yellow-30
  low:      '#0f62fe',  // blue-60
  none:     '#8d8d8d',  // gray-50
};

/** Certificate status colours (for DonutChart scale) */
export const STATUS_COLORS = {
  expired:       '#da1e28',
  expiring_soon: '#ff832b',
  valid:         '#24a148',
};

/** Derive severity string from raw CVSS score */
export function severityFromCvss(cvss: number): string {
  if (cvss >= 9) return 'critical';
  if (cvss >= 7) return 'high';
  if (cvss >= 4) return 'medium';
  if (cvss > 0)  return 'low';
  return 'none';
}

/** Human-readable days-remaining string */
export function formatDaysRemaining(days: number): string {
  if (days < 0)   return `Expired ${Math.abs(days)}d ago`;
  if (days === 0) return 'Expires today';
  return `${days}d remaining`;
}
```

---

## Skeleton Loading States

Show Carbon skeletons while data loads — never empty tables or blank tiles.

```tsx
import { SkeletonText } from '@carbon/react';

{/* In a DataTable */}
{loading ? (
  <div style={{ padding: '2rem' }}>
    <SkeletonText paragraph lineCount={6} />
  </div>
) : (
  <Table ...>...</Table>
)}

{/* In a detail Tile */}
{loading ? <SkeletonText paragraph lineCount={4} /> : <StructuredListWrapper ...>...</StructuredListWrapper>}

{/* In a KpiTile */}
{loading ? (
  <>
    <SkeletonText width="50%" />
    <SkeletonText heading width="35%" />
  </>
) : (
  <p style={{ fontSize: '2rem', ... }}>{value}</p>
)}
```

> ⚠️  `SkeletonText` does **not** accept a `style` prop. Use `width` and `heading` only.

---

## Forbidden Patterns

These patterns are explicitly banned — they break Carbon compliance or TypeScript:

| ❌ Wrong | ✅ Correct |
|---|---|
| `<h1 className="cds--heading-04">` | `<h1 style={{ fontSize: '1.5rem', fontWeight: 300, ... }}>` |
| `<div style={{ background: '#fff' }}>` wrapping a chart | `<Tile style={{ ... }}>` wrapping a chart |
| `<input type="search" ...>` in `TableToolbar` | `<TableToolbarSearch ... />` |
| `<Button kind="tertiary">← Back</Button>` | `<Button renderIcon={ArrowLeft} ...>Back</Button>` |
| `<Tag type="orange">` | No orange Tag exists. Use `type="teal"` or a colour-coded `<span>` |
| `<Tag size="md">` in a table cell | `<Tag size="sm">` |
| Bare `datetime.now()` / `datetime.utcnow()` in Python | `datetime.now(timezone.utc)` |
| `<h3 className="cds--heading-03">` for section titles | Inline-styled `<div>` with icon + `<p>` label |
| `import { Health } from '@carbon/icons-react'` | `import { Switcher }` — `Health` does not exist in v11 |
| `import { Software } from '@carbon/icons-react'` | `import { Application }` |
| `import { PackageImport } from '@carbon/icons-react'` | `import { Download }` |
| `<SkeletonText style={{ marginBottom: '0.5rem' }} />` | `<SkeletonText width="50%" />` — no `style` prop |
| `<StructuredListCell style={{ fontWeight: 500 }}>` (value cell, no color) | `<StructuredListCell style={{ fontWeight: 500, color: '#161616' }}>` — always pin Gray 100 on value cells |

---

## Component File Map

| Component | File | Primary Carbon components |
|---|---|---|
| App Shell | `src/components/Shell/AppShell.tsx` | `Header`, `HeaderNavigation`, `HeaderGlobalBar`, `Theme` |
| KPI Tile | `src/components/Shell/KpiTile.tsx` | `Tile`, `SkeletonText` |
| Data Fetch Notification | `src/components/Shell/DataFetchNotification.tsx` | `InlineNotification` |
| App Security | `src/components/AppSecurity/ApplicationSecurityDashboard.tsx` | `DataTable`, `SimpleBarChart`, `Tile`, `Tag`, `Pagination` |
| Vulnerability Drill-Through | `src/components/VulnerabilityDrillThrough/VulnerabilityDrillThrough.tsx` | `Breadcrumb`, `DataTable`, `DonutChart`, `StructuredList`, `Tag` |
| Software Composition | `src/components/SoftwareComposition/SoftwareCompositionDashboard.tsx` | `DataTable`, `SimpleBarChart`, `Modal`, `Tile`, `StructuredList` |
| Certificate Management | `src/components/CertificateManagement/CertificateManagementDashboard.tsx` | `DataTable`, `DonutChart`, `SimpleBarChart`, `InlineNotification`, `Tag` |
| System Health | `src/components/SystemHealth/SystemHealthDashboard.tsx` | `Tile`, `Tag`, `LineChart`, `StructuredList`, `InlineNotification` |
| Global CSS | `src/index.css` | CSS token overrides, IBM Plex Sans import |
| Format utils | `src/utils/format.ts` | `SEVERITY_COLORS`, `STATUS_COLORS`, `formatDaysRemaining`, `severityFromCvss` |
